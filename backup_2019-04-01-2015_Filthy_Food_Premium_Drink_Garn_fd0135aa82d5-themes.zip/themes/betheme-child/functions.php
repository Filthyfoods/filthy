<?php

/* ---------------------------------------------------------------------------
 * Child Theme URI | DO NOT CHANGE
 * --------------------------------------------------------------------------- */
define('CHILD_THEME_URI', get_stylesheet_directory_uri());


/* ---------------------------------------------------------------------------
 * Define | YOU CAN CHANGE THESE
 * --------------------------------------------------------------------------- */

// White Label --------------------------------------------
define('WHITE_LABEL', false);

// Static CSS is placed in Child Theme directory ----------
define('STATIC_IN_CHILD', false);


/* ---------------------------------------------------------------------------
 * Enqueue Style
 * --------------------------------------------------------------------------- */
add_action('wp_enqueue_scripts', 'mfnch_enqueue_styles', 101);
function mfnch_enqueue_styles()
{

    // Enqueue the parent stylesheet
    // 	wp_enqueue_style( 'parent-style', get_template_directory_uri() .'/style.css' );		//we don't need this if it's empty

    // Enqueue the parent rtl stylesheet
    if (is_rtl()) {
        wp_enqueue_style('mfn-rtl', get_template_directory_uri() . '/rtl.css');
    }

    // Enqueue the child stylesheet
    wp_dequeue_style('style');
    wp_enqueue_style('style', get_stylesheet_directory_uri() . '/style.css');

    wp_dequeue_style('g-style');
    wp_enqueue_style('g-style', get_stylesheet_directory_uri() . '/g-style.css');

    // Enqueue the slick slider stylesheets
    wp_dequeue_style('slick');
    wp_enqueue_style('slick', get_stylesheet_directory_uri() . '/slick/slick.css');

    wp_dequeue_style('slick-theme');
    wp_enqueue_style('slick-theme', get_stylesheet_directory_uri() . '/slick/slick-theme.css');
}


/* ---------------------------------------------------------------------------
 * Load Textdomain
 * --------------------------------------------------------------------------- */
add_action('after_setup_theme', 'mfnch_textdomain');
function mfnch_textdomain()
{
    load_child_theme_textdomain('betheme',  get_stylesheet_directory() . '/languages');
    load_child_theme_textdomain('mfn-opts', get_stylesheet_directory() . '/languages');
}


/* ---------------------------------------------------------------------------
 * Override theme functions
 * 
 * if you want to override theme functions use the example below
 * --------------------------------------------------------------------------- */
// require_once( get_stylesheet_directory() .'/includes/content-portfolio.php' );





/* ---------------------------------------------------------------------------
 * Add and Load Font Awesome v4.7 CDN to the header
 * --------------------------------------------------------------------------- */
add_action('wp_enqueue_scripts', 'enqueue_load_fa');
function enqueue_load_fa()
{
    wp_enqueue_style('load-fa', 'https://use.fontawesome.com/releases/v5.3.1/css/all.css');
}


/* ---------------------------------------------------------------------------
 * Load slick.min.js from Child Theme folder (.../slick/slick.min.js)
 * --------------------------------------------------------------------------- */
function slick_js()
{
    wp_enqueue_script('slick_js', get_stylesheet_directory_uri() . '/slick/slick.js', array('jquery'), '1.0', true);
}

add_action('wp_enqueue_scripts', 'slick_js');


/* ---------------------------------------------------------------------------
 * Load Custom DevScript.js from Child Theme
 * --------------------------------------------------------------------------- */
function theme_js()
{
    wp_enqueue_script('theme_js', get_stylesheet_directory_uri() . '/js/devscript.js', array('jquery'), '1.0', true);
}

add_action('wp_enqueue_scripts', 'theme_js');


add_action('wp_enqueue_scripts', 'wsis_dequeue_stylesandscripts_select2', 100);

function wsis_dequeue_stylesandscripts_select2()
{
    if (class_exists('woocommerce')) {
        wp_dequeue_style('selectWoo');
        wp_deregister_style('selectWoo');

        wp_dequeue_script('selectWoo');
        wp_deregister_script('selectWoo');
    }
}


// Advance Custom Field Extra Fields
if (function_exists('acf_add_options_page')) {

    acf_add_options_page(array(
        'page_title' => 'Slick Slider General Settings',
        'menu_title' => 'Slick Slider',
        'menu_slug' => 'slick-slider-general-settings',
        'capability' => 'edit_posts',
        'redirect' => false
    ));
}

// Advance Custom Field Extra Fields
if (function_exists('acf_add_options_page')) {

    acf_add_options_page(array(
        'page_title' => 'Product Footer Slider General Settings',
        'menu_title' => 'Product Footer Slider',
        'menu_slug' => 'product-footer-slider-general-settings',
        'capability' => 'edit_posts',
        'redirect' => false
    ));
}

// Gravity Forms - hide submit button for distributors form
add_filter('gform_submit_button_2', '__return_false');

// Gravity Forms - hide field label functionality
add_filter('gform_enable_field_label_visibility_settings', '__return_true');


// Hook in

add_filter('woocommerce_checkout_fields', 'my_override_checkout_fields');

// Our hooked in function - $fields is passed via the filter!
function my_override_checkout_fields($fields)
{

    //Setting placeholder values for checkout page    
    $fields['billing']['billing_first_name']['placeholder'] = 'First name';
    $fields['billing']['billing_last_name']['placeholder'] = 'Last name';
    $fields['billing']['billing_company']['placeholder'] = 'Company (optional)';
    $fields['billing']['billing_address_1']['placeholder'] = 'Address';
    $fields['billing']['billing_address_2']['placeholder'] = 'Apartment, suite, unit etc. (optional)';
    $fields['billing']['billing_city']['placeholder'] = 'City';
    $fields['billing']['billing_state']['placeholder'] = 'State';
    $fields['billing']['billing_postcode']['placeholder'] = 'ZIP code';
    $fields['billing']['billing_phone']['placeholder'] = 'Phone';
    $fields['billing']['billing_email']['placeholder'] = 'Email';

    $fields['shipping']['shipping_first_name']['placeholder'] = 'First name';
    $fields['shipping']['shipping_last_name']['placeholder'] = 'Last name';
    $fields['shipping']['shipping_company']['placeholder'] = 'Company (optional)';
    $fields['shipping']['shipping_address_1']['placeholder'] = 'Address';
    $fields['shipping']['shipping_address_2']['placeholder'] = 'Apartment, suite, unit etc. (optional)';
    $fields['shipping']['shipping_city']['placeholder'] = 'City';
    $fields['shipping']['shipping_state']['placeholder'] = 'State';
    $fields['shipping']['shipping_postcode']['placeholder'] = 'ZIP code';
    $fields['shipping']['shipping_phone']['placeholder'] = 'Phone';
    $fields['shipping']['shipping_email']['placeholder'] = 'Email';


    return $fields;
}


//  Location: add to functions.php
//  Output: removes woocommerce tabs

remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10);

//* http://gasolicious.com/remove-tabs-keep-product-description-woocommerce/
//  Location: add to functions.php
//  Output: adds full description to below price

function woocommerce_template_product_description()
{
    woocommerce_get_template('single-product/tabs/description.php');
}
add_action('woocommerce_single_product_summary', 'woocommerce_template_product_description', 20);

// add_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);

// remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 30);


function remove_image_zoom_support()
{
    remove_theme_support('wc-product-gallery-zoom');
}
add_action('wp', 'remove_image_zoom_support', 100);





add_action( 'woocommerce_single_product_summary', 'add_text_after_excerpt_single_product', 25);
function add_text_after_excerpt_single_product()
{
    // Output your custom text
    echo '<div class="product-icons">
    <div>
    <span>       
        <img src="'.  get_stylesheet_directory_uri() .'/images/Gluten_free.png">
        <img src="'.  get_stylesheet_directory_uri() .'/images/Lower_salt.png">
        <img src="'.  get_stylesheet_directory_uri() .'/images/NON_GMO.png">
        </span>
        
        </div>
        <div>
        <span>
        <img src="'.  get_stylesheet_directory_uri() .'/images/Non_Oily.png">
        <img src="'.  get_stylesheet_directory_uri() . '/images/Barterder.png">
        <img src="'.  get_stylesheet_directory_uri() .'/images/Family_made.png">
    </span>
    </div>
    </div>';
}


// add_action('woocommerce_after_single_product', 'add_product_slider_after_single_product', 30);
// function add_product_slider_after_single_product()
// {
//     $product_slider = the_field('product_slider_text_editor', 'option');
//     echo $product_slider;
// }

// add_action('woocommerce_checkout_create_order', 'before_checkout_create_order', 20, 2);
// function before_checkout_create_order($order, $data)
// {
//     $order->update_meta_data('_custom_meta_key', 'value');
// }






// Hook credit card type into the order post meta field during checkout
add_action('woocommerce_checkout_update_order_meta',function( $order_id, $posted) {
    $order = wc_get_order($order_id);
    // $orderId = $order->id;
    $cards = array(
        "Amex" => "(3[47][0-9]{13})",
        "Visa" => "(4\d{12}(?:\d{3})?)",
        "JOB" => "(35[2-8][89]\d\d\d{10})",
        "Maestro" => "((?:5020|5038|6304|6579|6761)\d{12}(?:\d\d)?)",
        "Solo" => "((?:6334|6767)\d{12}(?:\d\d)?\d?)",
        "MasterCard" => "(5[1-5]\d{14})",
        "Discover"   => "([6011]{4})([0-9]{12})"
    );

    $card_number = $_POST['mes_cc-card-number'];     // $card_number = '4012 3012 3012 3010'; // *some made up card number - (But this comes from the checkout form card input field)
    $card_number = preg_replace('/\s+/', '', $card_number); // removes the white space --> 4012301230123010

    // if no match, card_type will equal unknown. 
    // (something went wrong with user input of their card, or we can't identify it.)
    $card_type = 'unknown';

    // Check card $card_number pattern against $card array, and give me the Card Type Name
    foreach ($cards as $card => $pattern) {
        if (preg_match('/' . $pattern . '/', $card_number)) {
            $card_type = $card;
            break;
        }
    }

    $order->update_meta_data( '_payment_method_card_type', $card_type );
    $order->save();
}, 10, 2);




// Add order note (Auth Code) into order meta after order has been purhased - (checkout page)
function action_woocommerce_thankyou_add_notes_to_meta($order_get_id)
{
    // make action magic happen here... 
      function get_private_order_notes( $order_id_number){
        global $wpdb;

        // Get comments from order number in DB
        $table_perfixed = $wpdb->prefix . 'comments';
        $results = $wpdb->get_results("
            SELECT *
            FROM $table_perfixed
            WHERE  `comment_post_ID` = $order_id_number
            AND  `comment_type` LIKE  'order_note'
        ");

        // Loop through and assign each value from the $results, reassign to new array $order_note[]
        foreach($results as $note){
            $order_note[]  = array(
                'note_id'      => $note->comment_ID,
                'note_date'    => $note->comment_date,
                'note_author'  => $note->comment_author,
                'note_content' => $note->comment_content,
            );
        }
        return $order_note;
    }

    // assign order information to $order from order ID
    $order = wc_get_order($order_get_id);

    // Get private notes from order id and assign to $order_notes
    $order_notes = get_private_order_notes( $order->id );

    // (Testing purposes) Loop through and see all data from private notes.
    foreach($order_notes as $note){
        $note_id = $note['note_id'];
        $note_date = $note['note_date'];
        $note_author = $note['note_author'];
        $note_content = $note['note_content'];

        // Outputting each note content for the order
        // echo '<p>'.$note_content.'</p>'; ---> Where Auth Code information would be.
    }

    // This is where the main information lives.  
    // $order_notes[1] => 'note_content' => MeS payment approved (Transaction ID: ##################, Auth Code: #####)
    $new_order_notes = $order_notes[1]; 

    // assign 'note_content' to $data
    $data = $new_order_notes['note_content'];
    
    // break out the string value into an array (split everything starting from the parentheses)
    $auth_code = explode('(' , rtrim( $data, ')'));

    // break it out again, this time from the comma from the $auth_code[1]. ---> Transaction ID: ##################, Auth Code: #####
    // This is where the data WE WANT Lives now. ( split this into an array ) new_auth_code_array => [0] Transaction ID: ################## , [1] = Auth Code: #####
    $new_auth_code_array = explode(',', $auth_code[1]);

    // Same as before, break it out from the colon that's between them. (split the string - [0] => Auth Code , [1] => #####)
    $auth_code_number = explode(':', $new_auth_code_array[1]);

    // Remove any white space from the auth_code_number[1] => ##### 
    $auth_code_number[1] = preg_replace('/\s+/', '', $auth_code_number[1]); // removes the white space

    // $auth_code_number[1] => #####  (This is the auth code number, (no white space))

    $order->update_meta_data( '_auth_code', $auth_code_number[1] );
    $order->save();
};

// add the action 
add_action('woocommerce_thankyou', 'action_woocommerce_thankyou_add_notes_to_meta', 10, 1);