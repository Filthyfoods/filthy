=== Merchant e-Solutions WooCommerce Payment Gateway - CC ===
Contributors: naterchrdsn
Tags: payment gateway, merchant e-solutions, payment processing, woocommerce gateway
Requires at least: 4.2
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
WC requires at least: 2.2
WC tested up to: 2.3

This plugin allows processing of credit card transactions via the Merchant e-Solutions Payment Gateway & PayHere APIs. A merchant account is required.

== Description ==

**Merchant e-Solutions WooCommerce Payment Gateway Plugin**
*for Credit Card Transactions*

This addon for WordPress WooCommerce e-commerce plugin provides a direct payment gateway to the Merchant e-Solutions API.

== Changelog ==

= 0.0.1 =
* initial commit.

== Upgrade Notice ==
