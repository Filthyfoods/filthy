/*
Turn Visual Composer Image Carousel into Visual Composer Infinite Image Carousel
Include before the </head> tag on yout theme's header.php 
Read the detailed step-by-step at https://humbertosilva.com/visual-composer-infinite-image-carousel/
*/


// auxiliary code to create triggers for the add and remove class for later use
(function($){
$.each(["addClass","removeClass"],function(i,methodname){
    var oldmethod = $.fn[methodname];
    $.fn[methodname] = function(){
          oldmethod.apply( this, arguments );
          this.trigger(methodname+"change");
          return this;
    }
});
})(jQuery);

// main function for the infinite loop
function vc_custominfiniteloop_init(vc_cil_element_id){

  var vc_element = '#' + vc_cil_element_id; // because we're using this more than once let's create a variable for it
  window.maxItens = jQuery(vc_element).data('per-view'); // max visible items defined
  window.addedItens = 0; // auxiliary counter for added itens to the end 

  // go to slides and duplicate them to the end to fill space
  jQuery(vc_element).find('.vc_carousel-slideline-inner').find('.vc_item').each(function(){
    // we only need to duplicate the first visible images
    if (window.addedItens < window.maxItens) {
      if (window.addedItens == 0 ) {
        // the fisrt added slide will need a trigger so we know it ended and make it "restart" without animation
        jQuery(this).clone().addClass('vc_custominfiniteloop_restart').removeClass('vc_active').appendTo(jQuery(this).parent());            
      } else {
        jQuery(this).clone().removeClass('vc_active').appendTo(jQuery(this).parent());         
      }
      window.addedItens++;
    }
  });

  // add the trigger so we know when to "restart" the animation without the user knowing about it
  jQuery('.vc_custominfiniteloop_restart').bind('addClasschange', null, function(){

    // navigate to the carousel element , I know, its ugly ...
    var vc_carousel = jQuery(this).parent().parent().parent().parent();

    // first we temporarily change the animation speed to zero
    jQuery(vc_carousel).data('vc.carousel').transition_speed = 0;

    // make the slider go to the first slide without animation and because the fist set of images shown
    // are the same that are being shown now the slider is now "restarted" without that being visible 
    jQuery(vc_carousel).data('vc.carousel').to(0);

    // allow the carousel to go to the first image and restore the original speed 
    setTimeout("vc_cil_restore_transition_speed('"+jQuery(vc_carousel).prop('id')+"')",100);
  });

}

// restore original speed setting of vc_carousel
function vc_cil_restore_transition_speed(element_id){
// after inspecting the original source code the value of 600 is defined there so we put back the original here
jQuery('#' + element_id).data('vc.carousel').transition_speed = 600; 
}

// init     
jQuery(document).ready(function(){    
  // find all vc_carousel with the defined class and turn them into infine loop
  jQuery('.vc_custominfiniteloop').find('div[data-ride="vc_carousel"]').each(function(){
    // allow time for the slider to be built on the page
    // because the slider is "long" we can wait a bit before adding images and events needed  
    var vc_cil_element = jQuery(this).prop("id");
    setTimeout("vc_custominfiniteloop_init('"+vc_cil_element+"')",1);      
  });    
});

(function ($, root, undefined) {

  function getUrlParameter(sParam) {
      var sPageURL = decodeURIComponent(window.location.search.substring(1)),
          sURLVariables = sPageURL.split('&'),
          sParameterName,
          i;

      for (i = 0; i < sURLVariables.length; i++) {
          sParameterName = sURLVariables[i].split('=');

          if (sParameterName[0] === sParam) {
              return sParameterName[1] === undefined ? true : sParameterName[1];
          }
      }
  };

  function capitalize_Words(str) {
    return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
  }



// function addElement () { 
//   // create a new div element 
  
//   // and give it some content 
//   var newContent = document.createTextNode("FILTHY SELLS OUT FAST. REMEMBER TO CALL AHEAD."); 
//   // add the text node to the newly created div
//   newDiv.appendChild(newContent); 

//   // add the newly created element and its content into the DOM 
//   var currentDiv = document.getElementById("wpsl-search-wrap"); 
//   document.body.insertBefore(newDiv, currentDiv.nextSibling); 
// }

  //end sample use
  $(function () {

  var newDiv = "<div class='map-claim'><span>FILTHY SELLS OUT FAST. REMEMBER TO CALL AHEAD.</span></div>";
  $("#wpsl-search-wrap").append(newDiv);

    if (getUrlParameter('zip') != null && getUrlParameter('zip') != '') {
      zipcode = getUrlParameter('zip');
      $('#wpsl-search-input').val(zipcode);
      // $('#wpsl-search-btn').triggerHandler('click'); 
      
    } else {
      // lengthMinDisplay = lengthMin;
    }

      // 'use strict';
      //jQuery HERE



    $('.filthy-flip').slick({ // Slick slider for 'flip drinks images' - on Home Page.
      dots: false,
      infinite: true,
      slidesToShow: 7,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 2000,
      fade: true,
      cssEase: 'linear',
      responsive: [{
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
            dots: false
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
          slidesToShow: 1,
          slidesToScroll: 1
          }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
      ]

    });




    $('.filthy-for-life').slick({ // Slick slider for 'Filthy For life' - on Home Page.
      dots: false,
      slidesPerRow: 2,
      rows: 2,
      infinite: false,
      speed: 300,
      // slidesToShow: 2,
      slidesToScroll: 1,
      fade: true,
      cssEase: 'linear',
      mobileFirst: true,
      responsive: [{
          breakpoint: 1024,
          settings: {
            infinite: false,
            // slidesPerRow: 2,
            // rows: 1,
            slidesToShow: 1,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 768,
          settings: {
            // rows: 1,
            slidesPerRow: 1,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 100,
          settings: {
            slidesPerRow: 1,
            slidesToScroll: 1
          }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
      ]

    });

    //Start by hiding all products, only show the first filthy pickle
    $('.wpb_wrapper .woocommerce .products .product').hide();

    //Initail products to load (usually the filthy pickle)
    $('#post-156').show();
    $('#post-163').show();
    
    //Add the class name to each single product on home page
    $('#home-small-gallery .vc_carousel-slideline-inner .vc_item').each(function(){ 
      //grab the image title, and set that as the product thumbnail name 
      var thumbProductName = $(this).find('img').attr('title');

      //Adding classes
      if(thumbProductName == 'Filthy Black Cherry'){
        $(this).addClass('black-cherry-bkg');
      } else if (thumbProductName == 'Filthy Pickle'){
        $(this).addClass('pickle-olive-bkg');
      } else if (thumbProductName == 'Filthy Onion'){
        $(this).addClass('onion-bkg');
      } else if (thumbProductName == 'Filthy Pimento Olive'){
        $(this).addClass('pimento-bkg');
      } else if (thumbProductName == 'Filthy Red Cherry'){
        $(this).addClass('red-cherry-bkg');
      } else if (thumbProductName == 'Filthy Blue Cheese'){
        $(this).addClass('blue-cheese-bkg');
      } else if (thumbProductName == 'Filthy Pepper'){
        $(this).addClass('pepper-bkg');
      } else if (thumbProductName == 'xxxxxxx'){
        
      }
    });

    //On click of thumbnail, display product that match the thumbnail name and product ID
    $('#home-small-gallery .vc_carousel-slideline-inner').on('click', '.vc_item', function(){
      //grab the image title, and set that as the product thumbnail name
      var thumbProductName = $(this).find('img').attr('title');

      //Selecting what product ID to display
      if(thumbProductName == 'Filthy Black Cherry'){
        displayProductId = 'post-207';
      } else if (thumbProductName == 'Filthy Pickle'){
        displayProductId = 'post-156';
      } else if (thumbProductName == 'Filthy Onion'){
        displayProductId = 'post-271';
      } else if (thumbProductName == 'Filthy Pimento Olive'){
        displayProductId = 'post-268';
      } else if (thumbProductName == 'Filthy Red Cherry'){
        displayProductId = 'post-270';
      } else if (thumbProductName == 'Filthy Blue Cheese'){
        displayProductId = 'post-266';
      } else if (thumbProductName == 'Filthy Pepper'){
        displayProductId = 'post-267';
      } else if (thumbProductName == 'xxxxxxx'){
        displayProductId = 'post-';
      }

      //Hide all products first
      $('.wpb_wrapper .woocommerce .products .product').hide();

      //Show the clicked/selected product
      $('#' + displayProductId).show();

      //Use a different icon for both Cherry products, they are NOT family made
      if(thumbProductName == 'Black-Cherry' || thumbProductName == 'Red_Cherry') {
        $('.first-product-icon img').attr('src', 'http://filthy.jamesrossdev.com/wp-content/uploads/2018/10/all_natural.png');
      } else {
        $('.first-product-icon img').attr('src', 'http://filthy.jamesrossdev.com/wp-content/uploads/2018/10/family_made.png');
      }

    })

    // Setting the product name for each of the image
    $('#home-small-gallery .vc_carousel-slideline-inner .vc_item').each(function(){

      //grab the image title, and set that as the product thumbnail name
      var thumbProductName = $(this).find('img').attr('title');

      //Selecting what product ID to display
       if(thumbProductName == 'Filthy Black Cherry'){
        displayProductId = 'post-207';
      } else if (thumbProductName == 'Filthy Pickle'){
        displayProductId = 'post-156';
      } else if (thumbProductName == 'ONION'){
        displayProductId = 'post-271';
      } else if (thumbProductName == 'Pimento'){
        displayProductId = 'post-268';
      } else if (thumbProductName == 'Red_Cherry'){
        displayProductId = 'post-270';
      } else if (thumbProductName == 'Blue_cheese'){
        displayProductId = 'post-266';
      } else if (thumbProductName == 'Pepper'){
        displayProductId = 'post-267';
      } else if (thumbProductName == 'xxxxxxx'){
        displayProductId = 'post-';
      }

      //Formatting the display name
      var bundleDisplayName = thumbProductName.replace('-bundle', '');
      bundleDisplayName = bundleDisplayName.replace('_', ' ');
      bundleDisplayName = bundleDisplayName.replace('_', ' ');
      bundleDisplayName = capitalize_Words(bundleDisplayName);

      //console.log(bundleDisplayName);

      //Setting up the HTML markup for the display name for bundles
      var bundleDisplayNameHTML = '<div class="bundle-small-gallery-display-wrap"><h3 class="bundle-small-gallery-display-name">' + bundleDisplayName + '</h3></div>';

      //Adding the HTML markup to the DOM
      $(this).append(bundleDisplayNameHTML);

    });


    // Setting the product name for each of the Bundles
    $('#bundle-small-gallery .vc_carousel-slideline-inner .vc_inner ').each(function(){

      //grab the image title, and set that as the product thumbnail name
      var thumbProductName = $(this).find('img').attr('title');

      //Selecting what product ID to display
      if(thumbProductName == 'bar_setup_1-bundle'){
        displayProductId = 'post-163';
      } else if (thumbProductName == 'bloody_mary-bundle'){
        displayProductId = 'post-274';
      } else if (thumbProductName == 'martini-bundle'){
        displayProductId = 'post-275';
      } else if (thumbProductName == 'olive_lovers-bundle'){
        displayProductId = 'post-403';
      } else if (thumbProductName == 'blue_cheese-bundle'){
        displayProductId = 'post-405';
      } else if (thumbProductName == 'onion-bundle'){
        displayProductId = 'post-415';
      } else if (thumbProductName == 'pimento-bundle'){
        displayProductId = 'post-409';
      } else if (thumbProductName == 'pickle-bundle'){
        displayProductId = 'post-413';
      } else if (thumbProductName == 'pepper-bundle'){
        displayProductId = 'post-411';
      } else if (thumbProductName == 'black_cherry-bundle'){
        displayProductId = 'post-407';
      } else if (thumbProductName == 'bar_setup_2-bundle'){
        displayProductId = 'post-401';
      } else if (thumbProductName == 'red_cherry-bundle'){
        displayProductId = 'post-187';
      } else if (thumbProductName == 'xxxxxxx'){
        displayProductId = 'post-';
      } else {
        displayProductId = 'post-163';
      }

      //Formatting the display name
      var bundleDisplayName = thumbProductName.replace('-bundle', '');
      bundleDisplayName = bundleDisplayName.replace('_', ' ');
      bundleDisplayName = bundleDisplayName.replace('_', ' ');
      bundleDisplayName = capitalize_Words(bundleDisplayName);

      //console.log(bundleDisplayName);

      //Setting up the HTML markup for the display name for bundles
      var bundleDisplayNameHTML = '<div class="bundle-small-gallery-display-wrap"><h3 class="bundle-small-gallery-display-name">' + bundleDisplayName + '</h3></div>';

      //Adding the HTML markup to the DOM
      $(this).append(bundleDisplayNameHTML);

    });

    //On click of thumbnail, display product that match the thumbnail name and product ID
    $('#bundle-small-gallery .vc_carousel-slideline-inner').on('click', '.vc_item', function(){

      //grab the image title, and set that as the product thumbnail name
      var thumbProductName = $(this).find('img').attr('title');

      //Selecting what product ID to display
      if(thumbProductName == 'bar_setup_1-bundle'){
        displayProductId = 'post-163';
      } else if (thumbProductName == 'bloody_mary-bundle'){
        displayProductId = 'post-274';
      } else if (thumbProductName == 'martini-bundle'){
        displayProductId = 'post-275';
      } else if (thumbProductName == 'olive_lovers-bundle'){
        displayProductId = 'post-403';
      } else if (thumbProductName == 'blue_cheese-bundle'){
        displayProductId = 'post-405';
      } else if (thumbProductName == 'onion-bundle'){
        displayProductId = 'post-415';
      } else if (thumbProductName == 'pimento-bundle'){
        displayProductId = 'post-409';
      } else if (thumbProductName == 'pickle-bundle'){
        displayProductId = 'post-413';
      } else if (thumbProductName == 'pepper-bundle'){
        displayProductId = 'post-411';
      } else if (thumbProductName == 'black_cherry-bundle'){
        displayProductId = 'post-407';
      } else if (thumbProductName == 'bar_setup_2-bundle'){
        displayProductId = 'post-401';
      } else if (thumbProductName == 'red_cherry-bundle'){
        displayProductId = 'post-187';
      } else if (thumbProductName == 'xxxxxxx'){
        displayProductId = 'post-';
      } else {
        displayProductId = 'post-163';
      }

      //Hide all products first
      $('.wpb_wrapper .woocommerce .products .product').hide();

      //Show the clicked/selected product
      $('#' + displayProductId).show();

    })

    //On mouse hover, show/hide the product image on the home carousel
    $("#home-small-gallery .vc_carousel-inner .vc_carousel-slideline-inner").on("mouseover", ".vc_item", function() {  
        //Hide image
        $(this).find('img').hide();
    }).on("mouseout", ".vc_item", function() {
        //Show image
        $(this).find('img').show();
    });



    $('#Content .wpb_wrapper .woocommerce .products .product-info-wrap').each(function(){

      //FOR SETTING TEXT AROUND THE PRODUCT PRICE & DISCOUNT
      var valueText = '<p style="padding-right:5px;">Value </p>';
      $(this).find('.product-display-price del').prepend(valueText);

      var discountedPrice = $(this).find('.product-display-price del .amount').text().replace('$','');
      var actualPrice = $(this).find('.product-display-price ins .amount').text().replace('$','');

      discountedPrice = Number(discountedPrice);

      actualPrice = Number(actualPrice);

      var bundleDiscount = (1 - (actualPrice/discountedPrice)) * 100;

      bundleDiscount = Math.floor(bundleDiscount);

      var bundleDiscountText = "<br><p class='bundle-discount-text'>Bundle Discount " + bundleDiscount + "%</p>";
      $(this).find('.product-display-price del').append(bundleDiscountText);
      // END PRODUCT PRICE & DISCOUNT TEXT

      var productWrap = $(this);

      

      $(this).find('.attribute-size .value div:nth-child(1) input' ).attr('checked', true);


      $(this).find('.attribute-size input[type=radio]').change(function() {

        //alert("yay");

        //var variationPrice = productWrap.find('.woocommerce-variation-price .woocommerce-Price-amount').text();
        // console.log(variationPrice);

        // var displayPrice = productWrap.find('.product-display-price');

        //displayPrice.replaceWith(variationPrice);

      });

      //console.log($('.woocommerce-variation-price .woocommerce-Price-amount').text());



      // var variationPrice = $(this).find('.woocommerce-variation-price').text();
      // console.log(variationPrice);

      
      })


    // if ('#wc-mes_cc-cc-form').hasClass('.visa') {
    //   document.getElementById('cc_type').value = 'Visa';
    // } else if ('#wc-mes_cc-cc-form').hasClass('.mastercard') {
    //   document.getElementById('cc_type').value = 'MasterCard';
    // } else if ('#wc-mes_cc-cc-form').hasClass('.amex') {
    //   document.getElementById('cc_type').value = 'AmEx';
    // } else {
    //   document.getElementById('cc_type').value = 'Other';
    // }

    function getCreditCardType(accountNumber) {

      //start without knowing the credit card type
      var result = "unknown";

      //first check for MasterCard
      if (/^5[1-5]/.test(accountNumber))
      {
        result = "mastercard";
      }

      //then check for Visa
      else if (/^4/.test(accountNumber))
      {
        result = "visa";
      }

      //then check for AmEx
      else if (/^3[47]/.test(accountNumber))
      {
        result = "amex";
      }

      return result;


    }

    $('#shipping_phone_field').attr('data-priority', '100');
    $('#shipping_email_field').attr('data-priority', '110');

    $('#shipping_phone_field').hide();
    $('#shipping_email_field').hide();

    $('.payment_step').addClass('hiddenStep');

    $('#billing-step-btn').click(function(){

      if (!$('.payment_step').hasClass('hiddenStep')) {
        $('.payment_step').addClass('hiddenStep');
      }

      $('.info_step').removeClass('hiddenStep');
      
    })

    $('#shipping-step-btn').click(function(){

      if (!$('.payment_step').hasClass('hiddenStep')) {
        $('.payment_step').addClass('hiddenStep');
      }

      $('.info_step').removeClass('hiddenStep');
      
    })

    $('#submit-step-btn').click(function(){
      $('.payment_step').removeClass('hiddenStep');
      $('.info_step').toggleClass('hiddenStep');
    })

    $('.next-cart-step').click(function(){
      $('.payment_step').removeClass('hiddenStep');
      $('.info_step').toggleClass('hiddenStep');
    })
     


    //Home page filter buttons "Olives"
    $('#olive-filter').click(function(){
      console.log('olive-filter clicked');

      //if(!$('.product').hasClass('hiddenProduct')){
        $('.product').addClass('hiddenProduct');
      //}

      $('.product_cat-olive').removeClass('hiddenProduct');
    })

    //Home page filter buttons "Cherries"
    $('#cherry-filter').click(function(){
      console.log('cherry-filter clicked');

      //if(!$('.product').hasClass('hiddenProduct')){
        $('.product').addClass('hiddenProduct');
      //}

      $('.product_cat-cherry').removeClass('hiddenProduct');
    })

    //Home page filter buttons "Other"
    $('#other-filter').click(function(){
      console.log('other-filter clicked');

      $('.product').removeClass('hiddenProduct');
      $('.product_cat-cherry').addClass('hiddenProduct');
      $('.product_cat-olive').addClass('hiddenProduct');
    })


    // shift .product-icons under single product 'add-to-cart' form button
    $('.single-product .product .summary.entry-summary .product-icons').insertAfter('.single-product .product .summary.entry-summary .variations_form.cart');
    // $(".single-product .single_variation_wrap .variations").remove();
    // $(".single-product .single_variation_wrap .woocommerce-variation-add-to-cart").wrap("<div class='new'></div>");




  })
})(jQuery, this);

