<?php
if ( ! class_exists( 'acf_vc_helper' ) ) {
  class acf_vc_helper {

      public function __construct() {
          $this->construct = 'we are in the parent class';
      }

      public function text($field, $acf_version,$post_id) {
          $output = $field["value"];
          return apply_filters('acfvc_text',$output,$field,$post_id);
      }

      public function textarea($field, $acf_version,$post_id) {
          $output = $field["value"];
          return apply_filters('acfvc_textarea',$output,$field,$post_id);
      }

      public function wysiwyg($field, $acf_version,$post_id) {
          $output = $field["value"];
          return apply_filters('acfvc_wysiwyg',$output,$field,$post_id);
      }

      public function number($field, $acf_version,$post_id) {
          $output = $field["value"];
          return apply_filters('acfvc_number',$output,$field,$post_id);
      }

      public function email($field, $acf_version,$post_id) {
          $acfvc_option = get_option('acfvc_default');
          $email_as_link = false;
          if ($acfvc_option) {
              if (array_key_exists('email_as_link',$acfvc_option['general'])) {
                  $email_as_link = $acfvc_option['general']['email_as_link'];
              }
          }
          if ($email_as_link == true) {
              $output = '<a href="mailto:'.$field["value"].'">'.$field["value"].'</a>';
          } else {
              $output = $field["value"];
          }
          return apply_filters('acfvc_email',$output,$field,$post_id);
      }

      public function password($field, $acf_version,$post_id) {
          $output = $field["value"];
          return apply_filters('acfvc_password',$output,$field,$post_id);
      }


    public function image($field, $acf_version,$post_id) {
      $img_details = $field["value"];
      if($acf_version >= 5) {
        if($field["return_format"] == "array") {
          if(isset($img_details["url"])) {
            $output = '<img title="'.$img_details["title"].'" src="'.$img_details["url"].'" alt="'.$img_details["alt"].'" width="'.$img_details["width"].'" height="'.$img_details["height"].'" />';
          } else {
            $output = 'data-mismatch';
          }
        } elseif ($field["return_format"]=="url") {
          $output = '<img src="'.$img_details.'"/>';
        } elseif ($field["return_format"]=="id") {
          $img_details = wp_get_attachment_image_src($img_details);
          $output = '<img src="'.$img_details[0].'"/>';
        } else {
          $output = $field["value"];
        }
      } else {
        if($field["save_format"] == "object" ) {
        	if(isset($img_details["url"])) {
        		$output = '<img title="'.$img_details["title"].'" src="'.$img_details["url"].'" alt="'.$img_details["alt"].'" width="'.$img_details["width"].'" height="'.$img_details["height"].'" />';
        	} else {
        		$output = 'data-mismatch';
        	}
        } elseif ($field["save_format"]=="url") {
          $output = '<img src="'.$img_details.'"/>';
        } elseif ($field["save_format"]=="id") {
          $img_details = wp_get_attachment_image_src($img_details);
          $output = '<img src="'.$img_details[0].'"/>';
        } else {
          $output = $field["value"];
        }
      }
      return apply_filters('acfvc_image',$output,$field,$post_id);
    }

    public function file($field, $acf_version, $link_text,$post_id) {
      $file_details = $field["value"];
      if($acf_version >= 5) {
        if($field["return_format"] == "array" ) {
          if(isset($file_details["url"])) {
            $output = '<a title="Download '.$file_details["title"].'" href="'.$file_details["url"].'">'.$link_text.'</a>';
          } else {
            $output = 'data-mismatch';
          }
        } elseif ($field["return_format"]=="url") {
          $output = '<a title="Download" href="'.$file_details.'">'.$link_text.'</a>';
        } elseif ($field["return_format"]=="id") {
          $file_details = wp_get_attachment_url($file_details);
          $output = '<a title="Download" href="'.$file_details.'">'.$link_text.'</a>';
        } else {
          $output = $field["value"];
        }
      } else {
        if($field["save_format"] == "object" ) {
        	if(isset($file_details["url"])) {
        		$output = '<a title="Download '.$file_details["title"].'" href="'.$file_details["url"].'">'.$link_text.'</a>';
        	} else {
        		$output = 'data-mismatch';
        	}
        } elseif ($field["save_format"]=="url") {
          $output = '<a title="Download" href="'.$file_details.'">'.$link_text.'</a>';
        } elseif ($field["save_format"]=="id") {
          $file_details = wp_get_attachment_url($file_details);
          $output = '<a title="Download" href="'.$file_details.'">'.$link_text.'</a>';
        } else {
          $output = $field["value"];
        }
      }
      return apply_filters('acfvc_file',$output,$field,$link_text,$post_id);
    }

    public function select($field, $acf_version,$post_id) {
      if ( $field["multiple"] === 1 ) {
        if ( !empty($field["value"]) ) {
          $output = '<ul>';
          foreach ($field["value"] as $key => $value) {
              $output .= '<li class="'.$field["name"].' '.$field["name"].'_'.$key.'">'.$value.'</li>';
          }
          $output .= '</ul>';
        }
      } else {
        $output =  $field["value"];
      }
      return apply_filters('acfvc_select',$output,$field,$post_id);
    }

    public function checkbox($field, $acf_version,$post_id) {
      $check_values = $field["value"];
      $output = '';
      if ( $field["return_format"] == "array" ) {
          foreach ($check_values as $key => $value) {

              if ( $value == end($check_values) ) {
                  $output .= $value["label"];
              } else {
                  $output .= $value["label"].", ";
              }

          }
      } else {
          if(is_array($check_values)) {
            $output = implode(", ", $check_values);
          }
      }
      return apply_filters('acfvc_checkbox',$output,$field,$post_id);
    }

    public function radio($field, $acf_version,$post_id) {
      $radio_value = $field["value"];
      $output = '';
      if ( $field["return_format"] == "array" ) {
          $output = $radio_value["label"];
      } else {
          if ( !empty($radio_value) ) {
              $output = $radio_value;
          }
      }
      return apply_filters('acfvc_radio',$output,$field,$post_id);
    }

    public function user_return_displayname ($return_format, $field_value ) {

        // object
        if( $return_format == 'object' ) {
            $display_name = $field_value->data->display_name;
        // array
        } elseif( $return_format == 'array' ) {
            $display_name = $field_value["display_name"];
        // id
        } else {
            $user_data = get_userdata($field_value);
            $display_name = $user_data->data->display_name;
        }
        return $display_name;
    }

    public function user($field, $acf_version,$post_id) {

      $user_details = $field["value"];

      if (array_key_exists("field_type",$field))  {
        if ($field["field_type"]=="multi_select") {
          $output = "<ul>";
            foreach ($user_details as $key => $value) {
              $output .= "<li>".$value["display_name"]."</li>";
            }
          $output .= "</ul>";
        } else {
          $output = $user_details["display_name"];
        }
      } elseif (array_key_exists("multiple",$field)) {
        if ($field["multiple"]==1) {
          $output = "<ul>";
            foreach ($user_details as $key => $value) {
                $display_name = self::user_return_displayname($field["return_format"], $value);
              $output .= "<li>".$display_name."</li>";
            }
          $output .= "</ul>";
        } else {
            $display_name = self::user_return_displayname($field["return_format"], $user_details);
          $output = $display_name;
        }
      }
      return apply_filters('acfvc_user',$output,$field,$post_id);
    }

      public function page_link($field, $acf_version, $link_text,$post_id) {
          $page_link = $field["value"];
          if ($field["multiple"] == 1) {
              $output = "<ul>";
              foreach ($page_link as $key => $value) {
                  $output .= '<li><a title="'.$value.'" href="'.$value.'">'.$link_text.'</a></li>';
              }
              $output .= "</ul>";
          } else {
              $output = '<a title="'.$page_link.'" href="'.$page_link.'">'.$link_text.'</a>';
          }
          return apply_filters('acfvc_page_link',$output,$field,$link_text,$post_id);
      }

    public function google_map($field, $acf_version,$post_id) {
      $map_details = $field["value"];
      $output = '<iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q='.$map_details["lat"].','.$map_details["lng"].'&hl=es;z=14&amp;output=embed"></iframe>';
      return apply_filters('acfvc_google_map',$output,$field,$post_id);
    }

    public function date_picker($field, $acf_version,$post_id) {
      $acfvc_option = get_option('acfvc_default');
      if ($acfvc_option) {
          if (array_key_exists('date_format',$acfvc_option['general'])) {
              $date_format_selected = $acfvc_option['general']['date_format'];
          }
      }

      if ( $date_format_selected == "acf_default" ) {
          $output = $field["value"];
      } else {
          $unixtimestamp = strtotime($field["value"]);
          $date_format = get_option( 'date_format' );
          $output = date_i18n($date_format,$unixtimestamp);
      }
      return apply_filters('acfvc_date_picker',$output,$field,$post_id);
    }

    public function color_picker($field, $acf_version,$post_id) {
      $output = '<div style="display: inline-block; height: 15px; width: 15px; margin: 0px 5px 0px 0px; background-color: '.$field["value"].'"></div>'.$field["value"];
      return apply_filters('acfvc_color_picker',$output,$field,$post_id);
    }

    public function true_false($field, $acf_version,$post_id) {
      if(1 == $field["value"]) $output = 'True'; else $output = "False";
      return apply_filters('acfvc_true_false',$output,$field,$post_id);
    }

    public function taxonomy($field, $acf_version,$post_id) {
      $terms = $field["value"];
        if(!empty($terms)) {
          if ($field["field_type"]=="checkbox" OR $field["field_type"]=="multi_select") {
          $output = "<ul>";
          foreach($terms as $term) {
            $term_details = get_term( $term, 'category', ARRAY_A );
            $output .= '<li><a href="'.get_term_link( $term_details["term_id"], 'category' ).'" title="'.$term_details["name"].'">'.$term_details["name"].'</a></li>';
          }
          $output .= "</ul>";
        } elseif ($field["field_type"]=="radio" OR $field["field_type"]=="select") {
          $term_details = get_term( $terms, 'category', ARRAY_A );
          $output = '<a href="'.get_term_link( $term_details["term_id"], 'category' ).'" title="'.$term_details["name"].'">'.$term_details["name"].'</a>';
        }
      }
      return apply_filters('acfvc_taxonomy',$output,$field,$post_id);
    }

    public function post_object($field, $acf_version,$post_id) {
      $post_obj = $field["value"];
      $output = "<ul>";
      if (is_array($post_obj)) {
        foreach($post_obj as $post_obj_details) {
          if (array_key_exists("return_format",$field))  {
            if ($field["return_format"]=="id") {
              $post_id = $post_obj_details;
            } else {
              $post_id = $post_obj_details->ID;
            }
          } else {
            $post_id = $post_obj_details;
          }
          $output .= '<li><a href="'.get_permalink($post_id).'" title="'.get_the_title($post_id).'">'.get_the_title($post_id).'</a></li>';
        }
      } else {
        $output .= '<li><a href="'.get_permalink($post_obj).'" title="'.get_the_title($post_obj).'">'.get_the_title($post_obj).'</a></li>';
      }
      $output .= "</ul>";
      return apply_filters('acfvc_post_object',$output,$field,$post_id);
    }

    public function relationship($field, $acf_version,$post_id) {
      $posts = $field["value"];
      $output = "<ul>";
      foreach($posts as $post_details) {
      if ($field["return_format"]=="id") {
        $post_id = $post_details;
      } else {
        $post_id = $post_details->ID;
      }
        $output .= '<li><a href="'.get_permalink($post_id).'" title="'.get_the_title($post_id).'">'.get_the_title($post_id).'</a></li>';
      }
      $output .= "</ul>";
      return apply_filters('acfvc_relationship',$output,$field,$post_id);
    }

      public function url($field, $acf_version,$post_id) {
          $url = $field["value"];
          $output = '<a href="'.$url.'">'.$url.'</a>';
          return apply_filters('acfvc_url',$output,$field,$post_id);
      }

      public function link($field,$acf_version,$post_id) {
          $link = $field["value"];

          if ( $field["return_format"] == "array" ) {
              if ( empty( $link["title"] ) ) {
                   $link_titel =  $link["url"];
              } else {
                  $link_titel = $link["title"];
              }

              if ($link['target']) {
                  $link_target = $link['target'];
              } else {
                  $link_target = "_self";
              }

              $output = '<a href="'.esc_url($link["url"]).'" target="'.esc_attr($link_target).'">'.esc_html($link_titel).'</a>';
          } else{
              $output = '<a href="'.esc_url($link).'" >'.esc_html($link).'</a>';
          }
          return apply_filters('acfvc_link',$output,$field,$post_id);
      }

    public function oembed($field, $acf_version,$post_id) {
        $output = $field["value"];
        return apply_filters('acfvc_oembed',$output,$field,$post_id);
    }

    public function gallery($field, $acf_version, $gallery_options,$post_id) {
        /*https://codex.wordpress.org/Gallery_Shortcode*/
        $acfvc_option = get_option('acfvc_default');
        if  ($gallery_options["itemtag"] == 'default') {
            if ($acfvc_option) {
                if (array_key_exists('itemtag',$acfvc_option['gallery'])) {
                    $gallery_options["itemtag"] = $acfvc_option['gallery']['itemtag'];
                }
            }
        }
        if  ($gallery_options["icontag"] == 'default') {
            if ($acfvc_option) {
                if (array_key_exists('icontag',$acfvc_option['gallery'])) {
                    $gallery_options["icontag"] = $acfvc_option['gallery']['icontag'];
                }
            }
        }
        if  ($gallery_options["captiontag"] == 'default') {
            if ($acfvc_option) {
                if (array_key_exists('captiontag',$acfvc_option['gallery'])) {
                    $gallery_options["captiontag"] = $acfvc_option['gallery']['captiontag'];
                }
            }
        }

        $columns = "";
        if (!empty($gallery_options["columns"])) {
            $columns = 'columns="'.$gallery_options["columns"].'"';
        }
        $image_size = "";
        if ($gallery_options["image_size"]) {
            $image_size = 'size="'.$gallery_options["image_size"].'"';
        }
        $order_by = "";
        if ($gallery_options["order_by"]) {
            $order_by = 'orderby="'.$gallery_options["order_by"].'"';
        }
        $order = "";
        if ($gallery_options["order"]) {
            $order = 'order="'.$gallery_options["order"].'"';
        }
        $itemtag = "";
        if ($gallery_options["itemtag"]) {
            $itemtag = 'itemtag="'.$gallery_options["itemtag"].'"';
        }
        $icontag = "";
        if ($gallery_options["icontag"]) {
            $icontag = 'icontag="'.$gallery_options["icontag"].'"';
        }
        $captiontag = "";
        if ($gallery_options["captiontag"]) {
            $captiontag = 'captiontag="'.$gallery_options["captiontag"].'"';
        }
        $link = "";
        if ($gallery_options["link"]) {
            $link = 'link="'.$gallery_options["link"].'"';
        }
        $gallery_array = array();
        foreach ($field["value"] as $key => $value) {
            $gallery_array[] = intval($value["ID"]);
        }
        $gallery_images = implode(",",$gallery_array);
        $gallery = "[gallery include='{$gallery_images}' {$columns} {$image_size} {$order} {$order_by} {$itemtag} {$icontag} {$captiontag} {$link}]";
        return apply_filters('acfvc_gallery',do_shortcode($gallery),$field,$gallery_options,$post_id);
    }

    public function repeater_child($field, $args, $post_id) {
      $repeaterParentName = $args["repeaterParentName"];
      $acf_version = $args["acf_version"];
      $link_text = $args["link_text"];
      $gallery_options = $args["gallery_options"];

      $output = '<div class="reapeter-column '.$field["key"].' '.$field["name"].'">';
        if ( 'text' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::text($field, $acf_version, $post_id);
          }
        } elseif ( 'textarea' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::textarea($field, $acf_version, $post_id);
          }
        } elseif ( 'wysiwyg' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::wysiwyg($field, $acf_version, $post_id);
          }
        } elseif ( 'number' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::number($field, $acf_version, $post_id);
          }
        } elseif ( 'email' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::email($field, $acf_version, $post_id);
          }
        } elseif ( 'password' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::password($field, $acf_version, $post_id);
          }
        } elseif ( 'image' === $field["type"]) {
          if ( !empty($field["value"]) ) {
            $output .= self::image($field, $acf_version, $post_id);
          }
        } elseif('file' === $field["type"]) {
          if ( !empty($field["value"]) ) {
            $output .= self::file($field, $acf_version, $link_text, $post_id);
          }
  			} elseif ( 'select' === $field["type"]) {
          if ( !empty($field["value"]) ) {
            $output .= self::select($field, $acf_version, $post_id);
          }
        } elseif ( 'checkbox' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::checkbox($field, $acf_version, $post_id);
          }
  			} elseif ( 'radio' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::radio($field, $acf_version, $post_id);
          }
  			} elseif ( 'user' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::user($field, $acf_version, $post_id);
          }
  			} elseif ( 'page_link' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::page_link($field, $acf_version, $link_text, $post_id);
          }
  			} elseif ( 'google_map' === $field["type"] ) {
          if ( !empty($field["value"]) ) {
            $output .= self::google_map($field, $acf_version, $post_id);
          }
  			} elseif ('date_picker' === $field["type"]) {
          if ( !empty($field["value"]) ) {
            $output .= self::date_picker($field, $acf_version, $post_id);
          }
        } elseif ('color_picker' === $field["type"]) {
          if ( !empty($field["value"]) ) {
            $output .= self::color_picker($field, $acf_version, $post_id);
          }
        } elseif ('true_false' === $field["type"]) {
            $output .= self::true_false($field, $acf_version, $post_id);
        } elseif ('taxonomy' === $field["type"]) {
            $output .= self::taxonomy($field, $acf_version, $post_id);
        } elseif('post_object' === $field["type"]) {
          if ( !empty($field["value"]) ) {
            $output .= self::post_object($field, $acf_version, $post_id);
          }
		} elseif('relationship' === $field["type"]) {
          if ( !empty($field["value"]) ) {
            $output .= self::relationship($field, $acf_version, $post_id);
          }
		} elseif('url' === $field["type"]) {
          $output .= self::url($field, $acf_version, $post_id);
        } elseif('link' === $field["type"]) {
          $output .= self::link($field, $acf_version, $link_text, $post_id);
		} elseif('oembed' === $field["type"]) {
          $output .= self::oembed($field, $acf_version, $post_id);
      } elseif('gallery' === $field["type"]) {
          $output .= self::gallery($field, $acf_version, $gallery_options, $post_id);
      } elseif('repeater' === $field["type"]) {
        if (!empty($field['value'][0])) :
          $fieldNames = array_keys($field['value'][0]);
          $output .= '<div class="repeater-child-wrapper">';
            while ( have_rows($field['name'],$post_id) ) : the_row();
              $output .= '<div class="reapeater-row row-'.get_row_index().'">';
              foreach ($fieldNames as $key => $value) {
              $subSeild = get_sub_field_object($value);
                $subSeildValue = get_sub_field($value);
                $subSeild["value"] = $subSeildValue;
                $output .= self::repeater_child($subSeild,$args,$post_id);
              }
              $output .= '</div>';
            endwhile;
          $output .= '</div>';
        endif;
  		} else {
        // $output .= $field["type"]." is not supported";
        $output .= apply_filters( "acf_vc_repeater_add_on_fields",$field,$args,$post_id );
      }
      $output .= '</div>';

      return apply_filters('acfvc_sub_repeater',$output,$field,$args,$post_id);
    }

    public function repeater($field, $args, $post_id) {
        $args["repeaterParentName"] = $field["name"];
        $fieldNames = array_keys($field['value'][0]);
        $is_acf_repeater_active = is_acf_repeater_active();
        if (!empty($field['value'][0])) :
          $repeater = '<div class="repeater-wrapper">';
            while ( have_rows($field['name'],$post_id) ) : the_row();
              $repeater .= '<div class="reapeater-row row-'.get_row_index().'">';
              foreach ($fieldNames as $key => $value) {
              $subSeild = get_sub_field_object($value);
                if( $is_acf_repeater_active === true ) {
                  $subSeildValue = get_sub_field($value);
                  $subSeild["value"] = $subSeildValue;
                }
                $repeater .= self::repeater_child($subSeild,$args,$post_id);
              }
              $repeater .= '</div>';
            endwhile;
          $repeater .= '</div>';
          return apply_filters('acfvc_repeater',$repeater,$field,$args,$post_id);
        endif;
    }

  }
}
