<?php get_header(); ?>

	<main role="main" class="bgimg">
		<!-- section -->
		<section >

			<!-- article -->
			<article id="post-404" >
				<div >
					<h1 class="requested" ><?php _e( 'THE PAGE YOU REQUESTED<br> CANNOT BE FOUND.', 'html5blank' ); ?></h1>
					<!-- <h1 class="requested-mobile" ><?php _e( 'THE PAGE YOU<br>REQUESTED<br> CANNOT BE FOUND.', 'html5blank' ); ?></h1> -->
				</div>
				<div >
					<h1 class="p-404" ><?php _e( '404', 'html5blank' ); ?></h1>
				</div>
				<div>
					<h2 class="point-you"><?php _e( 'CAN WE POINT YOU IN THE <br> RIGHT DIRECTION?', 'html5blank' ); ?></h2>
				</div>
				<div class="move-link">
					<a class="link-color" href="http://filthy.jamesrossdev.com/products/"><h1><?php _e( 'Shop', 'html5blank' ); ?></h1></a>
					<a class="link-color" href="http://filthy.jamesrossdev.com/find-filthy/"><h1><?php _e( 'Find Filthy', 'html5blank' ); ?></h1></a>
					<a class="link-color" href="http://filthy.jamesrossdev.com/contact/"><h1><?php _e( 'Contact', 'html5blank' ); ?></h1></a>
					<a class="link-color" href="http://filthy.jamesrossdev.com/bundles/"><h1><?php _e( 'Bundles', 'html5blank' ); ?></h1></a>
				</div>
				

			</article>
			<!-- /article -->

		</section>
		<!-- /section -->
	</main>

<?php //get_sidebar(); ?>

<?php get_footer(); ?>
