<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;
global $post;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>

<li <?php wc_product_class(); ?> id="<?php echo esc_attr( 'post-' . get_the_ID() ); ?>">	
	<?php

	$link = apply_filters( 'woocommerce_loop_product_link', get_the_permalink(), $product );

	//echo '<a href="' . esc_url( $link ) . '" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">';


	if ( $product->is_on_sale() ) : ?>

	<?php echo apply_filters( 'woocommerce_sale_flash', '<span class="onsale">' . esc_html__( 'Sale!', 'woocommerce' ) . '</span>', $post, $product );

 	endif; ?>

 	<div class="product-background-image-wrap">
	 	<div class="product-background-image">
		 	<div class="col-md-4 offset-md-4 product-image-wrap">
			 	<?php
			 	echo '<h2 class="woocommerce-loop-product__title ">' . get_the_title() . '</h2>';
				echo woocommerce_get_product_thumbnail('full'); // WPCS: XSS ok.
				?>
			</div>
			<div class="col-md-4 product-info-wrap">
				<div class="product-info-inner-wrap">
				<?php
				


				//if ( $price_html = $product->get_price_html() ) : ?>
				
					<!-- <span class="price product-display-price"><?php echo $price_html; ?></span> -->
						
				<?php //endif;

				
				
				//echo '</a>';


				//UNCOMMENT FOR VARIATIONS
				

				//Get Available variations?
				if(count($product->get_children())){

					// Enqueue variation scripts.
					wp_enqueue_script( 'wc-add-to-cart-variation' );

					$get_variations = count( $product->get_children() ) <= apply_filters( 'woocommerce_ajax_variation_threshold', 30, $product );
				}

				if(count($get_variations) > 0){
					
						$available_variations = $get_variations ? $product->get_available_variations() : false;
						$attributes           = $product->get_variation_attributes();
						$selected_attributes  = $product->get_default_attributes();
					

					 ?>

					<form class="variations_form cart" method="post" enctype='multipart/form-data' data-product_id="<?php echo absint( $product->get_id() ); ?>" data-product_variations="<?php echo htmlspecialchars( wp_json_encode( $available_variations ) ) ?>">
						<?php do_action( 'woocommerce_before_variations_form' ); ?>

						<?php if ( empty( $available_variations ) && false !== $available_variations ) : ?>
							<p class="stock out-of-stock"><?php _e( 'This product is currently out of stock and unavailable.', 'woocommerce' ); ?></p>
						<?php else : ?>
							

							<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>

							<div class="single_variation_wrap">
								<?php
									//do_action( 'woocommerce_before_single_variation' );?>

									<script type="text/template" id="tmpl-variation-template">
										
										<div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
									
										<div class="woocommerce-variation-description long-description">{{{ data.variation.variation_description }}}</div>
										<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
									</script>
									<script type="text/template" id="tmpl-unavailable-variation-template">
										<p><?php _e( 'Sorry, this product is unavailable. Please choose a different combination.', 'woocommerce' ); ?></p>
									</script>

									<?php

									
									
									do_action( 'woocommerce_single_variation' );
									do_action( 'woocommerce_after_single_variation' );
								?>

								


							<table class="variations" cellspacing="0">
								<tbody>
									<?php foreach ( $attributes as $name => $options ) : ?>
										<tr class="attribute-<?php echo sanitize_title($name); ?>">
											<td class="label"><label for="<?php echo sanitize_title( $name ); ?>"><?php echo wc_attribute_label( $name ); ?></label></td>
											<?php
											$sanitized_name = sanitize_title( $name );
											if ( isset( $_REQUEST[ 'attribute_' . $sanitized_name ] ) ) {
												$checked_value = $_REQUEST[ 'attribute_' . $sanitized_name ];
											} elseif ( isset( $selected_attributes[ $sanitized_name ] ) ) {
												$checked_value = $selected_attributes[ $sanitized_name ];
											} else {
												$checked_value = '';
											}
											?>
											<td class="value">
												<?php
												if ( ! empty( $options ) ) {
													if ( taxonomy_exists( $name ) ) {
														// Get terms if this is a taxonomy - ordered. We need the names too.
														$terms = wc_get_product_terms( $product->get_id(), $name, array( 'fields' => 'all' ) );

														foreach ( $terms as $term ) {
															if ( ! in_array( $term->slug, $options ) ) {
																continue;
															}
															print_attribute_radio( $checked_value, $term->slug, $term->name, $sanitized_name );
														}
													} else {
														foreach ( $options as $option ) {
															print_attribute_radio( $checked_value, $option, $option, $sanitized_name );
														}
													}
												}

												echo end( $attribute_keys ) === $name ? apply_filters( 'woocommerce_reset_variations_link', '<a class="reset_variations" href="#">' . __( 'Clear', 'woocommerce' ) . '</a>' ) : '';
												?>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>

							<div class="woocommerce-variation-add-to-cart variations_button">
									<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>

									<div class="quantity-select-wrap">
										<div class="col-md-3 quantity-label">QUANTITY</div>
										<div class="col-md-8 quantity-input-wrap">
											<?php
											do_action( 'woocommerce_before_add_to_cart_quantity' );

											woocommerce_quantity_input( array(
												'min_value'   => apply_filters( 'woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product ),
												'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product ),
												'input_value' => isset( $_POST['quantity'] ) ? wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) : $product->get_min_purchase_quantity(), // WPCS: CSRF ok, input var ok.
											) );

											do_action( 'woocommerce_after_add_to_cart_quantity' );
											?>
										</div>
									</div>

									<button type="submit" class="single_add_to_cart_button button alt"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>

									<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>

									<input type="hidden" name="add-to-cart" value="<?php echo absint( $product->get_id() ); ?>" />
									<input type="hidden" name="product_id" value="<?php echo absint( $product->get_id() ); ?>" />
									<input type="hidden" name="variation_id" class="variation_id" value="0" />
								</div>

							</div>

							<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
						<?php endif; ?>

						<?php do_action( 'woocommerce_after_variations_form' ); ?>
					</form>

					<?php do_action( 'woocommerce_after_add_to_cart_form' ); 

				} else {//END VARIATIONS

					$short_description = apply_filters( 'woocommerce_short_description', $post->post_excerpt );

					$description_html = $product->get_description();


					if ( $price_html = $product->get_price_html() ) : ?>
				
					<span class="price product-display-price"><?php echo $price_html; ?></span>  <?php
					endif; ?>


					<div class="long-description"><?php echo $description_html; ?></div>

					<div class="woocommerce-product-details__short-description">
						<?php echo $short_description; // WPCS: XSS ok. ?>
					</div>
					<?php


					if ( $product->is_in_stock() ) : ?>

						<?php do_action( 'woocommerce_before_add_to_cart_form' ); ?>

						<!-- <form class="cart" action="<?php echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); ?>" method="post" enctype='multipart/form-data'> -->
						<form class="variations_form cart" method="post" enctype='multipart/form-data'>
							<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>
							<div class="quantity-select-wrap">
								<div class="col-md-3 quantity-label">QUANTITY</div>
								<div class="col-md-8 quantity-input-wrap">
									<?php
									do_action( 'woocommerce_before_add_to_cart_quantity' );

									woocommerce_quantity_input( array(
										'min_value'   => apply_filters( 'woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product ),
										'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product ),
										'input_value' => isset( $_POST['quantity'] ) ? wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) : $product->get_min_purchase_quantity(), // WPCS: CSRF ok, input var ok.
									) );

									do_action( 'woocommerce_after_add_to_cart_quantity' );
									?>
								</div>
							</div>

							<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="single_add_to_cart_button button alt"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>

							<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>

							<input type="hidden" name="add-to-cart" value="<?php echo absint( $product->get_id() ); ?>" />
									<input type="hidden" name="product_id" value="<?php echo absint( $product->get_id() ); ?>" />
									<input type="hidden" name="variation_id" class="variation_id" value="0" />
									
						</form>

						<?php do_action( 'woocommerce_after_add_to_cart_form' ); ?>

					<?php endif; 

					
				}?>
				</div>
			</div>
		</div>
		<div class="product-icon-row product-icon-row-left">
			<div class="col-md-3 product-icon first-product-icon">
				<img class="" src="http://filthy.jamesrossdev.com/wp-content/uploads/2018/10/family_made.png" width="276" height="276" alt="Family-Made" title="Family-Made" style="display: inline;">
			</div>
			<div class="col-md-3 product-icon">
				<img class="" src="http://filthy.jamesrossdev.com/wp-content/uploads/2018/10/bartender.png" width="276" height="276" alt="Bartender Approved" title="Bartender Approved" style="display: inline;">
			</div>
		</div>
		<div class="product-icon-row product-icon-row-right">
			<div class="col-md-3 product-icon">
				<img class="" src="http://filthy.jamesrossdev.com/wp-content/uploads/2018/10/gluten.png" width="276" height="276" alt="Gluten Free" title="Gluten Free" style="display: inline;">
			</div>
			<div class="col-md-3 product-icon">
				<img class="" src="http://filthy.jamesrossdev.com/wp-content/uploads/2018/10/gmo.png" width="276" height="276" alt="Non GMO" title="Non GMO" style="display: inline;">
			</div>
		</div>
	</div>
</li>

