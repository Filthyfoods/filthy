<?php
 namespace Sabberworm\CSS\Value; class CalcFunction extends CSSFunction { const T_OPERAND = 1; const T_OPERATOR = 2; } 